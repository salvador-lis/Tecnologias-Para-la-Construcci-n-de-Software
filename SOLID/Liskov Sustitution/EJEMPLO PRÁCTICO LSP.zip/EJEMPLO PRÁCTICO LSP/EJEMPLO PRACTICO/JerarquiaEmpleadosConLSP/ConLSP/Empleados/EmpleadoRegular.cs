using ConLSP.Interfaces;

namespace ConLSP.Empleados
{
    public class EmpleadoRegular : IEmpleado, IRemunerado
    {
        public string Nombre { get; }
        public string Puesto { get; }

        private readonly ITrabajador _trabajador;
        private readonly IRemunerado _remuneración;

        
    }
}
