using ConLSP.Interfaces;

namespace ConLSP.Empleados
{
    
}
