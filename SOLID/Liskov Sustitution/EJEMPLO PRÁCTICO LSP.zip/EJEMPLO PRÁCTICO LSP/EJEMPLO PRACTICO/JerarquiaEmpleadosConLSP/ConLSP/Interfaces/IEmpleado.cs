using System;

namespace ConLSP.Interfaces
{
    
}