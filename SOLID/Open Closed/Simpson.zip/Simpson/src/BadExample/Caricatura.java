package BadExample;

class Caricatura {
    String name;

    public Caricatura(String name) {
        this.name = name;
    }
}