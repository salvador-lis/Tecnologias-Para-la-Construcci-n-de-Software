package BadExample;

public class App {
    public static void main(String[] args) {
        Caricatura Homero = new Caricatura("Homero");
        Caricatura Bart = new Caricatura("Bart");
        Caricatura Lisa = new Caricatura("Lisa");

        Simpson.hablar(Homero);
        Simpson.hablar(Bart);
        Simpson.hablar(Lisa);
    }
}