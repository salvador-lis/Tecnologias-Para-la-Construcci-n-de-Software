package BadExample;

class Simpson {
    public static void hablar(Caricatura personaje) {
        switch (personaje.name) {
            case "Homero":
                System.out.println("¡D'oh!");
                break;
            case "Bart":
                System.out.println("¡Ay, caramba!");
                break;
            case "Lisa":
                System.out.println("Si alguien necesita yo estaré en mi cuarto.");
                break;
            default:
                System.out.println("Personaje no reconocido.");
        }
    }

    public static void eat(Caricatura personaje) {
        switch (personaje.name) {
            case "Homero":
                System.out.println("Mmm... rosquillas!");
                break;
            case "Bart":
                System.out.println("¡Cómeme mis pantalones cortos!");
                break;
            case "Lisa":
                System.out.println("Estoy comiendo una ensalada.");
                break;
            default:
                System.out.println("Personaje no reconocido.");
        }
    }
}