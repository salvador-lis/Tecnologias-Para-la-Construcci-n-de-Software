package GoodExample;

class Lisa implements Caricatura {
    public void speak() {
        System.out.println("I'm Lisa Simpson and I play the saxophone.");
    }

    public void eat() {
        System.out.println("I love my vegetarian meals!");
    }

    public void study() {
        System.out.println("Studying is important!");
    }
}