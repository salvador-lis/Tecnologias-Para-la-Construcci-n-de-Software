package GoodExample;

interface Caricatura {
    public void speak();

    public void eat();
}

