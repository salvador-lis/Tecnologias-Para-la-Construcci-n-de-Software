package GoodExample;

class Homer implements Caricatura {
    public void speak() {
        System.out.println("D'oh! I'm Homer Simpson.");
    }

    public void eat() {
        System.out.println("Mmm... donuts!");
    }

    public void work() {
        System.out.println("Working at the nuclear plant.");
    }
}