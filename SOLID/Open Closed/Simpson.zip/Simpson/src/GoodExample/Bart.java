package GoodExample;

class Bart implements Caricatura {
    public void speak() {
        System.out.println("Ay caramba! I'm Bart Simpson.");
    }
    public void eat() {
        System.out.println("Eat my shorts!");
    }

    public void prank() {
        System.out.println("Pranking is my specialty!");
    }
}
