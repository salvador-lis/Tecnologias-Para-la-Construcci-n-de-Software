package GoodExample;

public class App {
    public static void main(String[] args) {
        Homer homer = new Homer();
        Lisa lisa = new Lisa();
        Bart bart = new Bart();

        homer.speak();
        lisa.speak();
        bart.eat();
        homer.work();
        lisa.study();
    }
}
