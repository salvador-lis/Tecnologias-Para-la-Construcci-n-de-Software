public class App {

    public static double calculatePrice(double price, String discount) {
        if (discount.equals("10%")) {
            return price * 0.9;
        } else if (discount.equals("20%")) {
            return price * 0.8;
        } else if (discount.equals("30%")) {
            return price * 0.7;
        } else if (discount.equals("40%")) {
            return price * 0.6;
        }else {
            throw new IllegalArgumentException("Invalid discount");
        }
    }

    public static void main(String[] args) {
        double discountedPrice = calculatePrice(100, "10%");
        System.out.println("Your discounted price is " + discountedPrice);
    }
}
