import java.util.HashMap;
import java.util.Map;

public class DiscountCalculator {

    // Mapa de descuentos
    static Map<String, Double> discounts = new HashMap<>();

    static {
        discounts.put("10%", 0.9);
        discounts.put("20%", 0.8);
        discounts.put("30%", 0.7);
    }

    public static double calculatePrice(double price, String discountType) {
        Double discount = discounts.get(discountType);
        if (discount == null) {
            throw new IllegalArgumentException("Invalid discount");
        }
        return price * discount;
    }

    public static void main(String[] args) {
        double discountedPrice = calculatePrice(100, "30%");
        System.out.println("Your discounted price is $" + discountedPrice);
    }
}
