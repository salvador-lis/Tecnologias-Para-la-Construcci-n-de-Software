def calcular_descuento(tipo: str, precio: float) -> float:
    if tipo == "navidad":
        return precio * 0.90  # 10%
    elif tipo == "black_friday":
        return precio * 0.70  # 30%
    elif tipo == "cliente_frecuente":
        return precio * 0.80  # 20%
    else:
        return precio


# Uso
print("Navidad:", calcular_descuento("navidad", 1000))
print("Black Friday:", calcular_descuento("black_friday", 1000))
print("Cliente frecuente:", calcular_descuento("cliente_frecuente", 1000))