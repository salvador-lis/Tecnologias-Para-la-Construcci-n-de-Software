from DescuentoNavidad import DescuentoNavidad
from DescuentoBlackFriday import DescuentoBlackFriday
from DescuentoClienteFrecuente import DescuentoClienteFrecuente
from CalculadoraDescuentos import CalculadoraDescuentos

calc = CalculadoraDescuentos()

print("Navidad:", calc.calcular(100, DescuentoNavidad()))
print("Black Friday:", calc.calcular(1000, DescuentoBlackFriday()))
print("Cliente frecuente:", calc.calcular(1000, DescuentoClienteFrecuente()))