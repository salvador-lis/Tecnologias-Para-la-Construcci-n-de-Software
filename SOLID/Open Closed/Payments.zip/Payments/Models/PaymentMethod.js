export class PaymentMethod{
    pay(amount){
        throw new Error("Metodo pay() debe de ser implementado");
    }
}