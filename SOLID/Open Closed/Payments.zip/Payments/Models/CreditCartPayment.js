import { PaymentMethod } from "./PaymentMethod.js";

export class CreditCartPayment extends PaymentMethod{
    pay(amount){
        console.log("Pago procesado por tarjeta de credito $" + amount);
    }
}