import { PaymentService } from "./Services/PaymentService.js";
import { CreditCartPayment } from "./Models/CreditCartPayment.js";

const service = new PaymentService();

const creditCard= new CreditCartPayment();

service.processPayment(creditCard,150);