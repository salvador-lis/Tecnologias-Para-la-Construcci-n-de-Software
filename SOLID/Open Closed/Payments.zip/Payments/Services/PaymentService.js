export class PaymentService{
    processPayment(PaymentMethond,amount){
        PaymentMethond.pay(amount);
    }
}