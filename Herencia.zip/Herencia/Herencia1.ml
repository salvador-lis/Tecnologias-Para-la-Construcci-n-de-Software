class swimmer = object
  method swiw=print_endLine "swiming"
end;;

class cyclist = object
  mewthod pedal=print_andline "Pedaleando" 
end;;

class runner=object
  method run=print_endLine "logging in strava"

  class triathlete = object
    inherit swimmer
    inherit cyclist
    inherit runner
    method compete = print_andLine
      
        t.swiw
        t.pedal
                    
