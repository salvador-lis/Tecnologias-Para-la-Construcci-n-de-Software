class person name = object
  val mutable _name= name 
end;;

class student name = object
  inherit person name
  method study = print_endline "estudiando" 
end;;

class teacher name  = object
  inherit person name 
  method teach=print_endline "enseñando"
end;;

let emilio = new student "Emilio";;
emilio#study;;

let mag= new teacher "Mag";;
mag#teach;;