﻿using System;
using TiposdePolimorfismo.Figuras;
using TiposdePolimorfismo.Utilidades;
using TiposdePolimorfismo.Unidades;
using TiposdePolimorfismo.Genericos;


class Program
{
    public static void Porgram(string[] args)
    {
        List<Figura> figuras = new List<Figura>()
        {
            new Circulo(5),
            new Rectangulo(4,6)
        };

        foreach (var f in figuras)
        {
            f.dibujar();
            console.WriteLine($"Area: {f.calcularArea}");
        }

        Caja<String> caja1 = new Caja<string>();
        caja1.Guardar("Hola mundo");
        Console.WriteLine($"Contenido de la caja1:{caja1.Abrir()}");

        Caja<int> caja2 = new Caja<int>();
        caja2.Guardar(123);
        Console.WriteLine($"Contenido de la caja2:{caja2.Abrir()}");

        
        
    }
}

