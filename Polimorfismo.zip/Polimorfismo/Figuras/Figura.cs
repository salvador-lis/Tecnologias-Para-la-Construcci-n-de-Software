namespace TiposdePolimorfismo.Figuras
{
    public abstract class Figuras
    {
        public double calcularArea()
        {
            return 0;
        }

        public void dibujar()
        {
            Console.WriteLine("Dibujando Figura");
        }
    }
}