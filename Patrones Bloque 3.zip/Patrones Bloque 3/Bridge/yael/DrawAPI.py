
class draw_api():
    def __init__(self):
        pass