export class SoundSystem {
  playBackgroundMusic() {
    return "Reproduciendo música de fondo.";
  }
}
