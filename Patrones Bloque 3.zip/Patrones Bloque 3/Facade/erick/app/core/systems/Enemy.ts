export class Enemy {
  spawnEnemies() {
    return "Generando enemigos.";
  }
}
