# Facade

O fachada, crea una interfaz sencilla o simple que permite no ver la complejidad

## Resuelve

- Sistemas complejos
- Alto acoplamiento