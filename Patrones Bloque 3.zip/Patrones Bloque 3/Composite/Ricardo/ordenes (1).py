
class Orden:
    def ejecutar(self):
        pass
