using System;

namespace ProxyImagenDemo
{
    public interface IImagen
    {
        string Mostrar(); // devuelve la ruta del archivo mostrado
    }
}