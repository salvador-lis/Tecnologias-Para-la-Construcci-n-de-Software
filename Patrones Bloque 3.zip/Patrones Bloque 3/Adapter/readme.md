# Adapter

Es uno de los 23 patrones de la gang of four

se usa cuando hay interfaces que no son compatibles pero de una función similar

OMogeneizar la forma de trabajar

Se crea una clase intermedia: Adaptador

EJ.

Client con adapter

Target(interfaz) es una interfaz para crear los adapter

Adapter es la implementación de target

